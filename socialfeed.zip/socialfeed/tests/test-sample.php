<?php
/**
 * Class SampleTest
 *
 * @package Socialfeed
 */

/**
 * Sample test case.
 */
class SampleTest extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	function test_sample() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}

	function test_sample_string() {
		$string = 'Unit test are sweet';
		$this->assertEquals('Failing Unit tests are sad', $string);
	}
}
